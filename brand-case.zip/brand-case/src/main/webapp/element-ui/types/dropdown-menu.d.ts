import { ElementUIComponent } from './component'

/** Dropdown Menu Component */
export declare class ElDropdownMenu extends ElementUIComponent {}
